import states
import pyray
from raylib import colors


class Button:
    def __init__(self, x, y, texture):
        self.x = int(x)
        self.y = int(y)
        self.texture = texture

    def click(self):
        pyray.begin_drawing()
        if (self.x < pyray.get_mouse_x() < self.x + self.texture.width and
                self.y < pyray.get_mouse_y() < self.y + self.texture.height):
            if pyray.is_mouse_button_down(0):
                return 1
            pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)
        else:
            pyray.draw_texture(self.texture, self.x, self.y, colors.GRAY)
        pyray.end_drawing()


def main():
    pyray.init_window(states.Settings.WIDTH, states.Settings.HEIGHT, 'GTZLP_Inc_MGRN_to_SHP')
    pyray.set_target_fps(120)

    texture = states.loading('images/zavod.png')
    texture_exit = states.loading('images/button/exit.png')
    texture_play = states.loading('images/button/play.png')
    texture_skin = states.loading('images/button/skin.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.end_drawing()

    play = Button(states.Settings.WIDTH // 2.3 - states.Settings.WIDTH // 8, states.Settings.HEIGHT*10 // 22,
                  texture_play)
    skin = Button(states.Settings.WIDTH // 2.2, states.Settings.HEIGHT*10 // 22, texture_skin)

    exit_level = Button(states.Settings.WIDTH * 10 // 21 + states.Settings.WIDTH // 8,
                        states.Settings.HEIGHT * 10 // 22, texture_exit)

    while not pyray.window_should_close():
        if play.click():
            states.go_scene(7) # 7
        # переодевалка
        if skin.click():
            states.go_scene(6) # 6
        # выход
        if exit_level.click():
            pyray.end_drawing()
            pyray.close_window()
        pyray.end_drawing()
    pyray.close_window()


if __name__ == '__main__':
    main()
