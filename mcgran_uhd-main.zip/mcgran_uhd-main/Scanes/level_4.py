import states
from raylib import colors
import pyray
from random import choice


TILE = 100


class Cell:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.walls = {'top': True, 'right': True, 'bottom': True, 'left': True}
        self.drawing = {'top': True, 'right': True, 'bottom': True, 'left': True}
        self.visited = False
        self.thickness = 4
        self.grid_cells = []

    def draw(self):
        x, y = self.x * TILE, self.y * TILE
        walls = []

        if self.walls['top']:
            walls.append([pyray.Vector2(x, y), pyray.Vector2(x + TILE, y),
                          pyray.Rectangle(x, y, TILE, self.thickness), 'top'])
        if self.walls['right']:
            walls.append([pyray.Vector2(x + TILE, y), pyray.Vector2(x + TILE, y + TILE),
                          pyray.Rectangle(x + TILE, y, self.thickness, TILE), 'right'])
        if self.walls['bottom']:
            walls.append([pyray.Vector2(x + TILE, y + TILE), pyray.Vector2(x, y + TILE),
                          pyray.Rectangle(x, y + TILE, TILE, self.thickness), 'bottom'])
        if self.walls['left']:
            walls.append([pyray.Vector2(x, y + TILE), pyray.Vector2(x, y),
                          pyray.Rectangle(x, y, self.thickness, TILE), 'left'])
        return walls

    def check_cell(self, x, y):
        if x < 0 or x > states.Settings.WIDTH // TILE - 1 or y < 0 or y > states.Settings.HEIGHT // TILE - 1:
            return False
        return self.grid_cells[x + y * states.Settings.WIDTH // TILE]

    def check_neighbors(self, grid_cells):
        self.grid_cells = grid_cells
        neighbors = []
        top = self.check_cell(self.x, self.y - 1)
        right = self.check_cell(self.x + 1, self.y)
        bottom = self.check_cell(self.x, self.y + 1)
        left = self.check_cell(self.x - 1, self.y)
        if top and not top.visited:
            neighbors.append(top)
        if right and not right.visited:
            neighbors.append(right)
        if bottom and not bottom.visited:
            neighbors.append(bottom)
        if left and not left.visited:
            neighbors.append(left)
        return choice(neighbors) if neighbors else False


def remove_walls(current, nextt):
    dx = current.x - nextt.x
    if dx == 1:
        current.walls['left'] = False
        nextt.walls['right'] = False
    elif dx == -1:
        current.walls['right'] = False
        nextt.walls['left'] = False
    dy = current.y - nextt.y
    if dy == 1:
        current.walls['top'] = False
        nextt.walls['bottom'] = False
    elif dy == -1:
        current.walls['bottom'] = False
        nextt.walls['top'] = False


def generate_maze():
    grid_cells = [Cell(col, row) for row in range(states.Settings.HEIGHT // TILE)
                  for col in range(states.Settings.WIDTH // TILE)]
    current_cell = grid_cells[0]
    array = []
    break_count = 1

    while break_count != len(grid_cells):
        current_cell.visited = True
        next_cell = current_cell.check_neighbors(grid_cells)
        if next_cell:
            next_cell.visited = True
            break_count += 1
            array.append(current_cell)
            remove_walls(current_cell, next_cell)
            current_cell = next_cell
        elif array:
            current_cell = array.pop()
    return grid_cells


class Button:
    def __init__(self, x, y, texture):
        self.x = int(x)
        self.y = int(y)
        self.texture = texture

    def click(self):
        pyray.begin_drawing()
        if (self.x < pyray.get_mouse_x() < self.x + self.texture.width and
                self.y < pyray.get_mouse_y() < self.y + self.texture.height):
            if pyray.is_mouse_button_down(0):
                return 1
            pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)
        else:
            pyray.draw_texture(self.texture, self.x, self.y, colors.GRAY)
        pyray.end_drawing()


def win():
    texture = states.loading('images/Level_1/win.png')
    texture_exit = states.loading('images/button/exit.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.draw_text("MCgraw was finally able to get ", 440, 240, 24, colors.BLACK)
    pyray.draw_text("out of the meadow. ", 440, 280, 24, colors.BLACK)
    pyray.draw_text("He's one step closer to the goal", 440, 320, 24, colors.BLACK)
    pyray.draw_text("Forward to the MSHP!", 440, 360, 24, colors.BLACK)
    pyray.end_drawing()
    exit_level = Button(states.Settings.WIDTH - states.Settings.WIDTH // 7, states.Settings.HEIGHT * 10 // 13,
                        texture_exit)
    while not pyray.window_should_close():
        if exit_level.click():
            states.win(7)
            states.go_scene(7)
    pyray.close_window()


class Player:
    def __init__(self):
        self.player_speed = 5
        self.texture_right = states.loading(f'images/Level_4/{states.NAME}_head_right.png')
        self.texture_left = states.loading(f'images/Level_4/{states.NAME}_head_left.png')
        self.texture_up = states.loading(f'images/Level_4/{states.NAME}_head_up.png')
        self.texture_down = states.loading(f'images/Level_4/{states.NAME}_head_down.png')
        self.texture = self.texture_right
        self.center = pyray.Vector2(TILE // 2, TILE // 2)
        self.lines = [
            [self.center, pyray.Vector2(int(self.center.x), int(self.center.y + states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x), int(self.center.y - states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH), int(self.center.y))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH), int(self.center.y))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH),
                                        int(self.center.y + states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH),
                                        int(self.center.y - states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH),
                                        int(self.center.y - states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH),
                                        int(self.center.y + states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH*0.924),
                                        int(self.center.y + states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH*0.924),
                                        int(self.center.y - states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH*0.924),
                                        int(self.center.y - states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH*0.924),
                                        int(self.center.y + states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH*0.924),
                                        int(self.center.y + states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH*0.924),
                                        int(self.center.y - states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH*0.924),
                                        int(self.center.y - states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH*0.924),
                                        int(self.center.y + states.Settings.WIDTH*0.3826))],
        ]

    def draw(self):
        pyray.draw_texture(self.texture, int(self.center.x - self.texture.width//2),
                           int(self.center.y - self.texture.height//2), colors.WHITE)

    def move(self, maze):
        breaked = False
        if pyray.is_key_down(pyray.KeyboardKey.KEY_D):
            self.texture = self.texture_right
            self.center.x += self.player_speed
            for cell in maze:
                for wall in cell.draw():
                    if pyray.check_collision_recs(
                            pyray.Rectangle(int(self.center.x - TILE // 2 + 5),
                                            int(self.center.y - TILE // 2 + 5), TILE - 5, TILE - 5),
                            wall[2]):
                        self.center.x -= self.player_speed
                        breaked = True
                        break
                if breaked:
                    breaked = False
                    break
        elif pyray.is_key_down(pyray.KeyboardKey.KEY_A):
            self.texture = self.texture_left
            self.center.x -= self.player_speed
            for cell in maze:
                for wall in cell.draw():
                    if pyray.check_collision_recs(
                            pyray.Rectangle(int(self.center.x - TILE // 2 + 5),
                                            int(self.center.y - TILE // 2 + 5), TILE - 5, TILE - 5),
                            wall[2]):
                        self.center.x += self.player_speed
                        breaked = True
                        break
                if breaked:
                    breaked = False
                    break
        if pyray.is_key_down(pyray.KeyboardKey.KEY_W):
            self.texture = self.texture_up
            self.center.y -= self.player_speed
            for cell in maze:
                for wall in cell.draw():
                    if pyray.check_collision_recs(
                            pyray.Rectangle(int(self.center.x - TILE // 2 + 5),
                                            int(self.center.y - TILE // 2 + 5), TILE - 5, TILE - 5),
                            wall[2]):
                        self.center.y += self.player_speed
                        breaked = True
                        break
                if breaked:
                    break
        elif pyray.is_key_down(pyray.KeyboardKey.KEY_S):
            self.texture = self.texture_down
            self.center.y += self.player_speed
            for cell in maze:
                for wall in cell.draw():
                    if pyray.check_collision_recs(
                            pyray.Rectangle(int(self.center.x - TILE // 2 + 5),
                                            int(self.center.y - TILE // 2 + 5), TILE - 5, TILE - 5),
                            wall[2]):
                        self.center.y -= self.player_speed
                        breaked = True
                        break
                if breaked:
                    break
        if self.center.y < 0:
            win()
        self.lines = [
            [self.center, pyray.Vector2(int(self.center.x), int(self.center.y + states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x), int(self.center.y - states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH),
                                        int(self.center.y))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH),
                                        int(self.center.y))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH),
                                        int(self.center.y + states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH),
                                        int(self.center.y - states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH),
                                        int(self.center.y - states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH),
                                        int(self.center.y + states.Settings.WIDTH))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH*0.924),
                                        int(self.center.y + states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH*0.924),
                                        int(self.center.y - states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH*0.924),
                                        int(self.center.y - states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH*0.924),
                                        int(self.center.y + states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH*0.924),
                                        int(self.center.y + states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH*0.924),
                                        int(self.center.y - states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x + states.Settings.WIDTH*0.924),
                                        int(self.center.y - states.Settings.WIDTH*0.3826))],
            [self.center, pyray.Vector2(int(self.center.x - states.Settings.WIDTH*0.924),
                                        int(self.center.y + states.Settings.WIDTH*0.3826))],
        ]


def main():
    pyray.init_window(states.Settings.WIDTH+3, states.Settings.HEIGHT+3, 'GTZLP_Inc_MGRN_to_SHP')
    pyray.set_target_fps(60)
    # get maze
    maze = generate_maze()
    maze[0].walls['top'] = False
    point = pyray.Vector2(0, 0)
    points = []
    pointeds = []
    minn = states.Settings.WIDTH
    min_point = pyray.Vector2(0, 0)
    mgrn = Player()

    texture = states.loading('images/Level_4/flowers.png')
    while not pyray.window_should_close():
        pyray.begin_drawing()
        pyray.draw_texture(texture, 0, 0, colors.WHITE)
        for line in mgrn.lines:
            for cell in maze:
                for wall in cell.draw():
                    if pyray.check_collision_lines(wall[0], wall[1], line[0], line[1], point):
                        points.append(pyray.Vector2(point.x, point.y))

            for point in points:
                if ((point.x - mgrn.center.x)**2 + (point.y - mgrn.center.y)**2)**0.5 < minn:
                    minn = ((point.x - mgrn.center.x)**2 + (point.y - mgrn.center.y)**2)**0.5
                    min_point = point
            points = []
            pointeds.append(pyray.Vector2(min_point.x, min_point.y))
            minn = states.Settings.WIDTH

        for cell in maze:
            for wall in cell.draw():
                for point in pointeds:
                    if pyray.check_collision_point_line(point, wall[0], wall[1], 1):
                            cell.drawing[wall[3]] = False
                if not cell.drawing[wall[3]]:
                    pyray.draw_rectangle_rec(wall[2], colors.ORANGE)
        pointeds = []
        mgrn.move(maze)
        mgrn.draw()
        pyray.end_drawing()
    pyray.close_window()


if __name__ == '__main__':
    main()
