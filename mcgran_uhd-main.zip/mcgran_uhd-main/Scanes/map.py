import states
import pyray
from raylib import colors


class Button:
    def __init__(self, x, y, texture):
        self.x = int(x)
        self.y = int(y)
        self.texture = texture

    def click(self):
        pyray.begin_drawing()
        if (self.x < pyray.get_mouse_x() < self.x + self.texture.width and
                self.y < pyray.get_mouse_y() < self.y + self.texture.height):
            if pyray.is_mouse_button_down(0):
                return 1
            pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)
        else:
            pyray.draw_texture(self.texture, self.x, self.y, colors.GRAY)
        pyray.end_drawing()


def main():
    pyray.init_window(states.Settings.WIDTH, states.Settings.HEIGHT, 'GTZLP_Inc_MGRN_to_SHP')
    pyray.set_target_fps(120)

    texture = states.loading('images/map/map.png')
    texture_exit = states.loading('images/button/exit.png')
    texture_lvl1 = states.loading('images/map/map_lvl1.png')
    texture_lvl2 = states.loading('images/map/map_lvl2.png')
    texture_lvl3 = states.loading('images/map/map_lvl3.png')
    texture_lvl4 = states.loading('images/map/map_lvl4.png')
    texture_lvl5 = states.loading('images/map/map_lvl5.png')

    exit_level = Button(states.Settings.WIDTH - states.Settings.WIDTH // 7, states.Settings.HEIGHT * 10 // 13,
                        texture_exit)

    while not pyray.window_should_close():
        pyray.begin_drawing()
        if 131 < pyray.get_mouse_x() < 193 and 637 < pyray.get_mouse_y() < 700 and states.get_win() == 0:
            pyray.draw_texture(texture_lvl1, 0, 0, colors.WHITE)
            if pyray.is_mouse_button_down(0):
                states.go_scene(1)
        elif 228 < pyray.get_mouse_x() < 350 and 281 < pyray.get_mouse_y() < 389 and states.get_win() == 1:
            pyray.draw_texture(texture_lvl2, 0, 0, colors.WHITE)
            if pyray.is_mouse_button_down(0):
                states.go_scene(2)
        elif 556 < pyray.get_mouse_x() < 678 and 494 < pyray.get_mouse_y() < 601 and states.get_win() == 2:
            pyray.draw_texture(texture_lvl3, 0, 0, colors.WHITE)
            if pyray.is_mouse_button_down(0):
                states.go_scene(3)
        elif 780 < pyray.get_mouse_x() < 910 and 141 < pyray.get_mouse_y() < 279 and states.get_win() == 3:
            pyray.draw_texture(texture_lvl4, 0, 0, colors.WHITE)
            if pyray.is_mouse_button_down(0):
                states.go_scene(4)
        elif 1055 < pyray.get_mouse_x() < 1188 and 382 < pyray.get_mouse_y() < 490 and states.get_win() == 7:
            pyray.draw_texture(texture_lvl5, 0, 0, colors.WHITE)
            if pyray.is_mouse_button_down(0):
                states.go_scene(8)
        else:
            pyray.draw_texture(texture, 0, 0, colors.WHITE)

        if exit_level.click():
            states.go_scene(0)

        pyray.end_drawing()
    pyray.close_window()


if __name__ == '__main__':
    main()
