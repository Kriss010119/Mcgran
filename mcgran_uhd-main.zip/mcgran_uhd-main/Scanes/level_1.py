import random
import pyray
from raylib import colors
import states


class Button:
    def __init__(self, x, y, texture):
        self.x = int(x)
        self.y = int(y)
        self.texture = texture

    def click(self):
        pyray.begin_drawing()
        if (self.x < pyray.get_mouse_x() < self.x + self.texture.width and
                self.y < pyray.get_mouse_y() < self.y + self.texture.height):
            if pyray.is_mouse_button_pressed(0):
                return 1
            pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)
        else:
            pyray.draw_texture(self.texture, self.x, self.y, colors.GRAY)
        pyray.end_drawing()


def text_desk():
    pyray.draw_rectangle(210, 690, 890, 60, colors.BLACK)


def light_on_off(room, light, slovar):
    rnd = random.randint(0, 4)
    if pyray.is_mouse_button_pressed(0) and states.LIGHT[light] == 0:
        states.LIGHT[light] = 1
        texture_room = states.room_texture(room, states.LIGHT[light])
        pyray.draw_texture(texture_room, 0, 0, colors.WHITE)
        text_desk()
        pyray.draw_text(slovar[rnd], 240, 710, 24, colors.WHITE)
    elif pyray.is_mouse_button_pressed(0) and states.LIGHT[light] == 1:
        states.LIGHT[light] = 0
        texture_room = states.room_texture(room, states.LIGHT[light])
        pyray.draw_texture(texture_room, 0, 0, colors.WHITE)
        text_desk()
        pyray.draw_text(slovar[rnd], 240, 710, 24, colors.WHITE)


def ne_suget(slovar):
    rnd = random.randint(0, 4)
    if pyray.is_mouse_button_pressed(0):
        text_desk()
        pyray.draw_text(slovar[rnd], 240, 710, 24, colors.WHITE)


# LIVING
def room_1():
    texture_right = states.loading('images/Level_1/right.png')
    texture_left = states.loading('images/Level_1/left.png')
    texture_clock_note = states.loading('images/Level_1/clock_note.png')
    texture_notes_note = states.loading('images/Level_1/notes_note.png')
    texture_plant_note = states.loading('images/Level_1/plant_note.png')
    texture_room = states.room_texture(1, states.LIGHT[0])

    pyray.begin_drawing()
    pyray.draw_texture(texture_room, 0, 0, colors.WHITE)
    pyray.end_drawing()

    right = Button(states.Settings.WIDTH - states.Settings.WIDTH // 12,
                   states.Settings.HEIGHT - states.Settings.HEIGHT // 7,
                   texture_right)
    left = Button(states.Settings.WIDTH // 100,
                  states.Settings.HEIGHT - states.Settings.HEIGHT // 7,
                  texture_left)

    clock_note = False
    notes_note = False
    plant_note = False

    while not pyray.window_should_close():
        pyray.begin_drawing()

        if (not clock_note) and (not notes_note) and (not plant_note):
            # GO_RIGHT_ROOM_2
            if right.click():
                states.ROOM = 2
                return
            # GO_LEFT_ROOM_4
            if left.click():
                states.ROOM = 4
                return

            if 1225 < pyray.get_mouse_x() < 1295 and 490 < pyray.get_mouse_y() < 566:
                light_on_off(1, 0, states.SLOVAR_DVERI["light"])

            if 400 < pyray.get_mouse_x() < 710 and 475 < pyray.get_mouse_y() < 640:
                ne_suget(states.SLOVAR_LIVING_ROOM["sofa"])
            if 14 < pyray.get_mouse_x() < 160 and 520 < pyray.get_mouse_y() < 640:
                ne_suget(states.SLOVAR_LIVING_ROOM["safe"])
            if 220 < pyray.get_mouse_x() < 315 and 230 < pyray.get_mouse_y() < 330:
                ne_suget(states.SLOVAR_LIVING_ROOM["axolotl"])
            if 750 < pyray.get_mouse_x() < 890 and 250 < pyray.get_mouse_y() < 400:
                ne_suget(states.SLOVAR_LIVING_ROOM["paint"])
            if 87 < pyray.get_mouse_x() < 215 and 250 < pyray.get_mouse_y() < 340:
                ne_suget(states.SLOVAR_LIVING_ROOM["shelf"])
            if 940 < pyray.get_mouse_x() < 1210 and 250 < pyray.get_mouse_y() < 636:
                ne_suget(states.SLOVAR_LIVING_ROOM["book"])
            if ((735 < pyray.get_mouse_x() < 895 and 535 < pyray.get_mouse_y() < 650) or
                    (215 < pyray.get_mouse_x() < 370 and 535 < pyray.get_mouse_y() < 650)):
                ne_suget(states.SLOVAR_LIVING_ROOM["cupboard"])

            # OPEN CLOCK_NOTE
            if 485 < pyray.get_mouse_x() < 630 and 255 < pyray.get_mouse_y() < 400:
                if pyray.is_mouse_button_pressed(0):
                    if states.GAME[6] == 1:
                        clock_note = True
                        states.GAME[7] = 1
                        pyray.draw_texture(texture_clock_note, 300, 200, colors.WHITE)
                    else:
                        ne_suget(states.SLOVAR_LIVING_ROOM["clock"])
            # OPEN NOTES_NOTE
            if 70 < pyray.get_mouse_x() < 350 and 365 < pyray.get_mouse_y() < 435:
                if pyray.is_mouse_button_pressed(0):
                    if states.GAME[7] == 1:
                        notes_note = True
                        states.GAME[8] = 1
                        pyray.draw_texture(texture_notes_note, 300, 200, colors.WHITE)
                        ne_suget(states.SLOVAR_LIVING_ROOM["notes"])
                else:
                    ne_suget(states.SLOVAR_LIVING_ROOM["notes"])
            # OPEN PLANT_NOTE
            if 825 < pyray.get_mouse_x() < 890 and 475 < pyray.get_mouse_y() < 530:
                if pyray.is_mouse_button_pressed(0):
                    if states.GAME[8] == 1:
                        notes_note = True
                        states.GAME[9] = 1
                        pyray.draw_texture(texture_plant_note, 300, 200, colors.WHITE)
        elif clock_note:
            if not(300 < pyray.get_mouse_x() < 1050 and 200 < pyray.get_mouse_y() < 640):
                if pyray.is_mouse_button_pressed(0):
                    clock_note = False
                    pyray.draw_texture(states.room_texture(1, 1), 0, 0, colors.WHITE)
        elif notes_note:
            if not(300 < pyray.get_mouse_x() < 1050 and 200 < pyray.get_mouse_y() < 640):
                if pyray.is_mouse_button_pressed(0):
                    notes_note = False
                    pyray.draw_texture(states.room_texture(1, 1), 0, 0, colors.WHITE)
        elif plant_note:
            if not(300 < pyray.get_mouse_x() < 1050 and 200 < pyray.get_mouse_y() < 640):
                if pyray.is_mouse_button_pressed(0):
                    plant_note = False
                    pyray.draw_texture(states.room_texture(1, 1), 0, 0, colors.WHITE)
        pyray.end_drawing()
    pyray.close_window()


# KITCHEN
def room_2():
    texture_right = states.loading('images/Level_1/right.png')
    texture_left = states.loading('images/Level_1/left.png')
    texture_room = states.room_texture(2, states.LIGHT[1])
    texture_crocodile = states.loading('images/Level_1/krok.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture_room, 0, 0, colors.WHITE)
    pyray.end_drawing()

    right = Button(states.Settings.WIDTH - states.Settings.WIDTH // 12,
                   states.Settings.HEIGHT - states.Settings.HEIGHT // 7,
                   texture_right)
    left = Button(states.Settings.WIDTH // 100,
                  states.Settings.HEIGHT - states.Settings.HEIGHT // 7,
                  texture_left)

    while not pyray.window_should_close():
        pyray.begin_drawing()
        # GO_RIGHT_ROOM_3
        if right.click():
            states.ROOM = 3
            return
        # GO_LEFT_ROOM_1
        if left.click():
            states.ROOM = 1
            return

        if 1225 < pyray.get_mouse_x() < 1295 and 490 < pyray.get_mouse_y() < 566:
            light_on_off(2, 1, states.SLOVAR_DVERI["light"])

        if 600 < pyray.get_mouse_x() < 780 and 350 < pyray.get_mouse_y() < 440:
            ne_suget(states.SLOVAR_KITCHEN["microwave"])
        if ((630 < pyray.get_mouse_x() < 780 and 451 < pyray.get_mouse_y() < 800) or
                (600 < pyray.get_mouse_x() < 1205 and 180 < pyray.get_mouse_y() < 300) or
                (1018 < pyray.get_mouse_x() < 1212 and 480 < pyray.get_mouse_y() < 800)):
            ne_suget(states.SLOVAR_KITCHEN["cupboard"])
        if ((45 < pyray.get_mouse_x() < 450 and 491 < pyray.get_mouse_y() < 630) or
                (220 < pyray.get_mouse_x() < 290 and 531 < pyray.get_mouse_y() < 685)):
            ne_suget(states.SLOVAR_KITCHEN["table"])
        if ((460 < pyray.get_mouse_x() < 513 and 436 < pyray.get_mouse_y() < 580) or
                (360 < pyray.get_mouse_x() < 513 and 581 < pyray.get_mouse_y() < 685)):
            ne_suget(states.SLOVAR_KITCHEN["chair"])
        if 315 < pyray.get_mouse_x() < 370 and 390 < pyray.get_mouse_y() < 490:
            ne_suget(states.SLOVAR_KITCHEN["JBL"])
        if 800 < pyray.get_mouse_x() < 1015 and 380 < pyray.get_mouse_y() < 625:
            ne_suget(states.SLOVAR_KITCHEN["oven"])
        if 65 < pyray.get_mouse_x() < 425 and 210 < pyray.get_mouse_y() < 360:
            ne_suget(states.SLOVAR_KITCHEN["picture"])
        if 15 < pyray.get_mouse_x() < 193 and 13 < pyray.get_mouse_y() < 106:
            if pyray.is_mouse_button_pressed(0):
                ne_suget(states.SLOVAR_KITCHEN["crocodile"])
                pyray.draw_texture(texture_crocodile, 13, 12, colors.WHITE)

        if 1020 < pyray.get_mouse_x() < 1160 and 410 < pyray.get_mouse_y() < 470:
            if pyray.is_mouse_button_pressed(0):
                text_desk()
                if states.GAME[3] == 1:
                    states.GAME[6] = 1
                    pyray.draw_text("How did I not notice that! 'Purpx lbhe jngpu'", 240, 710, 24, colors.WHITE)
                else:
                    pyray.draw_text("My favourite salad", 240, 710, 24, colors.WHITE)
        pyray.end_drawing()
    pyray.close_window()


def win():
    texture = states.loading('images/Level_1/win.png')
    texture_exit = states.loading('images/button/exit.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.draw_text("McGraw did his homework for the networks.", 385, 240, 24, colors.BLACK)
    pyray.draw_text("Now he goes to the MSHP to try to get ", 385, 280, 24, colors.BLACK)
    pyray.draw_text("to class on time.", 385, 320, 24, colors.BLACK)
    pyray.end_drawing()
    exit_level = Button(states.Settings.WIDTH - states.Settings.WIDTH // 7, states.Settings.HEIGHT * 10 // 13,
                        texture_exit)
    while not pyray.window_should_close():
        if exit_level.click():
            states.win(1)
            states.go_scene(7)
    pyray.close_window()


# ROOM_WITH_DOORS
def room_3():
    texture_right = states.loading('images/Level_1/right.png')
    texture_left = states.loading('images/Level_1/left.png')
    texture_room = states.room_texture(3, states.LIGHT[2])
    texture_room_light_on = states.room_texture(3, 1)
    texture_menu_die1 = states.loading('images/Level_1/menu_die1.png')
    texture_menu_die2 = states.loading('images/Level_1/menu_die2.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture_room, 0, 0, colors.WHITE)
    pyray.end_drawing()

    you_die = False

    right = Button(states.Settings.WIDTH - states.Settings.WIDTH // 12,
                   states.Settings.HEIGHT - states.Settings.HEIGHT // 7,
                   texture_right)
    left = Button(states.Settings.WIDTH // 100,
                  states.Settings.HEIGHT - states.Settings.HEIGHT // 7,
                  texture_left)

    while not pyray.window_should_close():
        if not you_die:
            pyray.begin_drawing()
            # GO_RIGHT_ROOM_4
            if right.click():
                states.ROOM = 4
                return
            # GO_LEFT_ROOM_2
            if left.click():
                states.ROOM = 2
                return

            if 1225 < pyray.get_mouse_x() < 1295 and 490 < pyray.get_mouse_y() < 566:
                light_on_off(3, 2, states.SLOVAR_DVERI["light"])

            if 940 < pyray.get_mouse_x() < 1210 and 240 < pyray.get_mouse_y() < 740:
                if pyray.is_mouse_button_pressed(0):
                    # КАРТИНКА_ТЫ_УМЕР
                    states.DIE -= 1
                    you_die = True
                    text_desk()
                    pyray.draw_text("You died... Why did you opened this door?",
                                    240, 710, 24, colors.WHITE)

            if 525 < pyray.get_mouse_x() < 790 and 245 < pyray.get_mouse_y() < 740:
                if pyray.is_mouse_button_pressed(0):
                    text_desk()
                    if not states.GAME[10]:
                        pyray.draw_text(f'You cannot open it... {states.SLOVAR_GAME["door"]}',
                                        240, 710, 24, colors.WHITE)
                        states.GAME[0] = 1
                    if states.GAME[10]:
                        win()

            if 100 < pyray.get_mouse_x() < 370 and 245 < pyray.get_mouse_y() < 740:
                if pyray.is_mouse_button_pressed(0):
                    text_desk()
                    if not states.GAME[10]:
                        pyray.draw_text(f'It is closed too... {states.SLOVAR_GAME["door"]}',
                                        240, 710, 24, colors.WHITE)
                        states.GAME[0] = 1
                    if states.GAME[10]:
                        win()
        elif you_die:
            if states.DIE > 0:
                pyray.draw_texture(texture_menu_die1, 300, 200, colors.WHITE)
                if 560 < pyray.get_mouse_x() < 750 and 510 < pyray.get_mouse_y() < 610:
                    if pyray.is_mouse_button_pressed(0):
                        you_die = False
                        pyray.draw_texture(texture_room_light_on, 0, 0, colors.WHITE)
            else:
                pyray.draw_texture(texture_menu_die2, 300, 200, colors.WHITE)
                if 560 < pyray.get_mouse_x() < 750 and 510 < pyray.get_mouse_y() < 610:
                    if pyray.is_mouse_button_pressed(0):
                        you_die = False
                        states.DIE = 3
                        for i in range(11):
                            states.GAME[i] = 0
                        f = open('States.txt', 'w')
                        f.write('0')
                        f.close()
                        states.go_scene(0)
        pyray.end_drawing()
    pyray.close_window()


# BED_ROOM
def room_4():
    texture_right = states.loading('images/Level_1/right.png')
    texture_left = states.loading('images/Level_1/left.png')
    texture_room = states.room_texture(4, states.LIGHT[3])
    texture_comp = states.loading('images/Level_1/comp_screen.png')
    texture_comp_email = states.loading('images/Level_1/comp_screen_email.png')
    texture_comp_korzina = states.loading('images/Level_1/comp_screen_korzina.png')
    texture_comp_pust = states.loading('images/Level_1/comp_screen_pust.png')
    texture_ship_note = states.loading('images/Level_1/ship_note.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture_room, 0, 0, colors.WHITE)
    pyray.end_drawing()

    right = Button(states.Settings.WIDTH - states.Settings.WIDTH // 12,
                   states.Settings.HEIGHT - states.Settings.HEIGHT // 7,
                   texture_right)
    left = Button(states.Settings.WIDTH // 100,
                  states.Settings.HEIGHT - states.Settings.HEIGHT // 7,
                  texture_left)

    open_comp = False
    open_email = False
    open_korzina = False
    ship_note = False

    while not pyray.window_should_close():
        pyray.begin_drawing()

        if (not open_comp) and (not open_email) and (not open_korzina) and (not ship_note):
            # GO_RIGHT_ROOM_1
            if right.click():
                states.ROOM = 1
                return
            # GO_LEFT_ROOM_3
            if left.click():
                states.ROOM = 3
                return

            if 1225 < pyray.get_mouse_x() < 1295 and 490 < pyray.get_mouse_y() < 566:
                light_on_off(4, 3, states.SLOVAR_DVERI["light"])

            if 900 < pyray.get_mouse_x() < 975 and 330 < pyray.get_mouse_y() < 430:
                ne_suget(states.SLOVAR_BEDROOM["cactus"])
            elif 880 < pyray.get_mouse_x() < 1170 and 230 < pyray.get_mouse_y() < 450:
                ne_suget(states.SLOVAR_BEDROOM["window"])
            if 6 < pyray.get_mouse_x() < 450 and 535 < pyray.get_mouse_y() < 778:
                ne_suget(states.SLOVAR_BEDROOM["bed"])
            if 1015 < pyray.get_mouse_x() < 1095 and 580 < pyray.get_mouse_y() < 655:
                ne_suget(states.SLOVAR_BEDROOM["mop"])
            if 305 < pyray.get_mouse_x() < 381 and 425 < pyray.get_mouse_y() < 616:
                ne_suget(states.SLOVAR_BEDROOM["guitar"])
            if 725 < pyray.get_mouse_x() < 825 and 310 < pyray.get_mouse_y() < 400:
                ne_suget(states.SLOVAR_BEDROOM["calendar"])
            if 460 < pyray.get_mouse_x() < 480 and 160 < pyray.get_mouse_y() < 260:
                ne_suget(states.SLOVAR_BEDROOM["book"])
            if 470 < pyray.get_mouse_x() < 820 and 430 < pyray.get_mouse_y() < 560:
                ne_suget(states.SLOVAR_BEDROOM["comp"])
            if 485 < pyray.get_mouse_x() < 985 and 516 < pyray.get_mouse_y() < 690:
                ne_suget(states.SLOVAR_BEDROOM["chair"])
            if 494 < pyray.get_mouse_x() < 810 and 570 < pyray.get_mouse_y() < 685:
                ne_suget(states.SLOVAR_BEDROOM["table"])
            if 1120 < pyray.get_mouse_x() < 1300 and 590 < pyray.get_mouse_y() < 800:
                ne_suget(states.SLOVAR_BEDROOM["cupboard"])

            if 410 < pyray.get_mouse_x() < 535 and 290 < pyray.get_mouse_y() < 585:
                if states.GAME[9] == 0:
                    ne_suget(states.SLOVAR_BEDROOM["ship"])
                else:
                    if pyray.is_mouse_button_pressed(0):
                        ship_note = True
                        states.GAME[10] = 1
                        pyray.draw_texture(texture_ship_note, 300, 200, colors.WHITE)
            # FIND NOTE WITH PASSWORD
            if 505 < pyray.get_mouse_x() < 545 and 745 < pyray.get_mouse_y() < 775:
                if pyray.is_mouse_button_pressed(0):
                    text_desk()
                    pyray.draw_text(states.SLOVAR_GAME["note"], 240, 710, 24, colors.WHITE)
                    states.GAME[1] = 1
            if 615 < pyray.get_mouse_x() < 760 and 430 < pyray.get_mouse_y() < 570:
                if pyray.is_mouse_button_pressed(0):
                    text_desk()
                    if states.GAME[1] == 1:
                        pyray.draw_text(states.SLOVAR_GAME["comp"][1], 240, 710, 24, colors.WHITE)
                        states.GAME[2] = 1
                        # OPEN COMPUTER
                        open_comp = True
                    else:
                        pyray.draw_text(states.SLOVAR_GAME["comp"][0], 240, 710, 24, colors.WHITE)

        # OPEN COMPUTER
        elif open_comp and (not open_korzina) and (not open_email):
            # OPEN COMPUTER
            if states.GAME[3] == 0:
                pyray.draw_texture(texture_comp, 100, 140, colors.WHITE)
            else:
                pyray.draw_texture(texture_comp_pust, 100, 140, colors.WHITE)
            if 130 < pyray.get_mouse_x() < 330 and 180 < pyray.get_mouse_y() < 245:
                if pyray.is_mouse_button_pressed(0):
                    open_comp = False
                    pyray.draw_texture(states.room_texture(4, 1), 0, 0, colors.WHITE)
            # OPEN EMAIL
            if (280 < pyray.get_mouse_x() < 420 and 340 < pyray.get_mouse_y() < 445
                    and (not open_email) and (not open_korzina)):
                if pyray.is_mouse_button_pressed(0):
                    pyray.draw_texture(texture_comp_email, 100, 140, colors.WHITE)
                    states.GAME[3] = 1
                    open_email = True
            # OPEN COMP KORZINA
            if (565 < pyray.get_mouse_x() < 705 and 320 < pyray.get_mouse_y() < 435
                    and (not open_email) and (not open_korzina)):
                if pyray.is_mouse_button_pressed(0):
                    pyray.draw_texture(texture_comp_korzina, 100, 140, colors.WHITE)
                    states.GAME[4] = 1
                    open_korzina = True
        # OPEN COMPUTER + OPEN EMAIL
        elif open_comp and (not open_korzina) and open_email:
            pyray.draw_texture(texture_comp_email, 100, 140, colors.WHITE)
            if 130 < pyray.get_mouse_x() < 330 and 180 < pyray.get_mouse_y() < 245:
                if pyray.is_mouse_button_pressed(0):
                    pyray.draw_texture(states.room_texture(4, 1), 0, 0, colors.WHITE)
                    open_comp = False
                    open_email = False
            if 800 < pyray.get_mouse_x() < 850 and 210 < pyray.get_mouse_y() < 260:
                if pyray.is_mouse_button_pressed(0):
                    pyray.draw_texture(texture_comp_pust, 100, 140, colors.WHITE)
                    open_email = False
        # OPEN COMPUTER + OPEN KORZINA
        elif open_comp and open_korzina and (not open_email):
            pyray.draw_texture(texture_comp_korzina, 100, 140, colors.WHITE)
            if 130 < pyray.get_mouse_x() < 330 and 180 < pyray.get_mouse_y() < 245:
                if pyray.is_mouse_button_pressed(0):
                    pyray.draw_texture(states.room_texture(4, 1), 0, 0, colors.WHITE)
                    open_comp = False
                    open_korzina = False
            if 900 < pyray.get_mouse_x() < 945 and 260 < pyray.get_mouse_y() < 300:
                if pyray.is_mouse_button_pressed(0):
                    pyray.draw_texture(texture_comp_pust, 100, 140, colors.WHITE)
                    open_korzina = False
        # OPEN SHIP_NOTE
        elif ship_note:
            if not(300 < pyray.get_mouse_x() < 1050 and 200 < pyray.get_mouse_y() < 640):
                if pyray.is_mouse_button_pressed(0):
                    ship_note = False
                    pyray.draw_texture(states.room_texture(4, 1), 0, 0, colors.WHITE)
        pyray.end_drawing()
    pyray.close_window()


def room_5(texture):
    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.end_drawing()

    texture_exit = states.loading('images/exit.png')
    states.win(1)
    exit_button = Button(states.Settings.WIDTH - states.Settings.WIDTH // 7,
                         states.Settings.HEIGHT * 10 // 13, texture_exit)
    while not pyray.window_should_close():
        if exit_button.click():
            states.go_scene(7)
    pyray.close_window()


def main():
    pyray.init_window(states.Settings.WIDTH, states.Settings.HEIGHT, 'GTZLP_Inc_MGRN_to_SHP')
    pyray.set_target_fps(120)  # FPS

    texture_room5 = states.loading('images/Level_1/win.png')
    texture1 = states.loading('images/Level_1/dark_room.png')
    pyray.begin_drawing()
    pyray.draw_texture(texture1, 0, 0, colors.WHITE)
    pyray.end_drawing()

    while not pyray.window_should_close():
        if states.ROOM == 1:
            room_1()
        elif states.ROOM == 2:
            room_2()
        elif states.ROOM == 3:
            room_3()
        elif states.ROOM == 4:
            room_4()
        elif states.ROOM == 5:
            room_5(texture_room5)

    pyray.close_window()


if __name__ == '__main__':
    main()
