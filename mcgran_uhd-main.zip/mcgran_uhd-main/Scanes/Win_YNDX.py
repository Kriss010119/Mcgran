import states
import pyray
from raylib import colors


class Button:
    def __init__(self, x, y, texture):
        self.x = int(x)
        self.y = int(y)
        self.texture = texture

    def click(self):
        pyray.begin_drawing()
        if (self.x < pyray.get_mouse_x() < self.x + self.texture.width and
                self.y < pyray.get_mouse_y() < self.y + self.texture.height):
            if pyray.is_mouse_button_down(0):
                return 1
            pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)
        else:
            pyray.draw_texture(self.texture, self.x, self.y, colors.GRAY)
        pyray.end_drawing()


def main():
    pyray.init_window(states.Settings.WIDTH, states.Settings.HEIGHT, 'GTZLP_Inc_MGRN_to_SHP')
    pyray.set_target_fps(120)

    texture = states.loading('images/Win_YNDX/YANDEX.png')
    texture_exit = states.loading('images/button/replay.png')
    texture_skin = states.loading('images/Win_MSHP/villain.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.end_drawing()

    skin = Button(890, 450, texture_skin)
    exit_level = Button(1150, 650, texture_exit)

    clik = 0
    text = {
        "0": "Hi MCgran.",
        "1": "Congratulations on your successful completion.",
        "2": "You came just in time for the defense and you weren't late.",
        "3": "Successful completion of the project!",
    }
    win = False
    while not pyray.window_should_close():
        # ПЕРЕОДЕВАЛКА
        if skin.click():
            pyray.draw_rectangle(250, 630, 800, 150, colors.BLACK)
            pyray.draw_text(text["0"], 270, 650, 24, colors.WHITE)
            pyray.draw_text(text["1"], 270, 680, 24, colors.WHITE)
            pyray.draw_text(text["2"], 270, 710, 24, colors.WHITE)
            pyray.draw_text(text["3"], 270, 740, 24, colors.WHITE)
            win = True

        # ВЫХОД
        if win and exit_level.click():
            states.win(0)
            states.go_scene(0)

        pyray.end_drawing()
    pyray.close_window()


if __name__ == '__main__':
    main()
