import states
import pyray
from raylib import colors
import random
import math
from enum import Enum


bg = (255, 255, 255, 255)

score = 0
score_speedup = 100
game_speed = 8.0


class Button:
    def __init__(self, x, y, texture):
        self.x = int(x)
        self.y = int(y)
        self.texture = texture

    def click(self):
        pyray.begin_drawing()
        if (self.x < pyray.get_mouse_x() < self.x + self.texture.width and
                self.y < pyray.get_mouse_y() < self.y + self.texture.height):
            if pyray.is_mouse_button_down(0):
                return 1
            pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)
        else:
            pyray.draw_texture(self.texture, self.x, self.y, colors.GRAY)
        pyray.end_drawing()


def win():
    texture = states.loading('images/Level_1/win.png')
    texture_exit = states.loading('images/button/exit.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.draw_text("McGraw was able to resist ", 440, 240, 24, colors.BLACK)
    pyray.draw_text("the temptation and walk ", 440, 280, 24, colors.BLACK)
    pyray.draw_text("past the arcade machines. ", 440, 320, 24, colors.BLACK)
    pyray.draw_text("There's a bus ride ahead!", 440, 360, 24, colors.BLACK)
    pyray.end_drawing()
    exit_level = Button(states.Settings.WIDTH - states.Settings.WIDTH // 7, states.Settings.HEIGHT * 10 // 13,
                        texture_exit)
    while not pyray.window_should_close():
        if exit_level.click():
            states.go_scene(7)
    pyray.close_window()


class DinoState(Enum):
    RUN = 1
    JUMP = 2


class Dino:
    jump_power = 10
    cur_jump_power = jump_power
    sprites = {
        "run": [],
        "jump": []
    }
    image = None
    run_animation_index = [0, 5]
    state = DinoState.RUN
    box = None

    def __init__(self, x, y, color="default"):
        self.color = color
        self.load_sprites()
        self.box = pyray.Rectangle(x, y, self.sprites["run"][0].width, self.sprites["run"][0].height)
        self.image = self.sprites["run"][0]

    def load_sprites(self):
        self.sprites["jump"].append(states.loading(f"images/Level_2/dino/{states.NAME}_jump.png"))
        self.sprites["run"].append(states.loading(f"images/Level_2/dino/{states.NAME}.png"))
        self.sprites["run"].append(states.loading(f"images/Level_2/dino/{states.NAME}_run.png"))

    def update(self):
        if self.state == DinoState.RUN:
            self.run()
        elif self.state == DinoState.JUMP:
            self.jump()

    def run(self):

        self.image = self.sprites["run"][self.run_animation_index[0] // self.run_animation_index[1]]

        self.run_animation_index[0] += 1
        if self.run_animation_index[0] >= self.run_animation_index[1] * 2:
            self.run_animation_index[0] = 0

    def jump(self):
        if self.state == DinoState.JUMP:
            self.box.y -= self.cur_jump_power * (2 * (game_speed / 8))
            self.cur_jump_power -= 0.5 * (game_speed / 8)

            if self.cur_jump_power <= -self.jump_power:
                self.box.y -= self.cur_jump_power * (2 * (game_speed / 8))
                self.state = DinoState.RUN
                self.cur_jump_power = self.jump_power
            if self.box.y >= states.Settings.HEIGHT - 250:
                self.box.y = states.Settings.HEIGHT - 250
                self.state = DinoState.RUN
                self.cur_jump_power = self.jump_power
        else:
            self.state = DinoState.JUMP
            self.image = self.sprites["jump"][0]

    def draw(self):
        pyray.draw_texture(self.image, int(self.box.x), int(self.box.y), colors.WHITE)


class Cactus:
    def __init__(self, x, y, texture):
        self.is_active = True
        self.texture = texture
        self.hitbox = pyray.Rectangle(x, y - self.texture.height, self.texture.width, self.texture.height)

    def update(self):
        self.hitbox.x -= game_speed
        if self.hitbox.x < -self.hitbox.width:
            # remove this cactus
            self.is_active = False

    def draw(self):
        pyray.draw_texture(self.texture, int(self.hitbox.x), int(self.hitbox.y), colors.WHITE)


def calc_dist(a, b):
    dx = a[0] - b[0]
    dy = a[1] - b[1]

    return math.sqrt(dx ** 2 + dy ** 2)


def main():
    global game_speed, score, score_speedup

    game_speed = 8.0
    score = 0
    score_speedup = 100

    pyray.init_window(states.Settings.WIDTH, states.Settings.HEIGHT, 'GTZLP_Inc_MGRN_to_SHP')
    pyray.set_target_fps(60)
    textures = [states.loading('images/Level_2/cactus/1.png'),
                states.loading('images/Level_2/cactus/2.png'),
                states.loading('images/Level_2/cactus/3.png'),
                states.loading('images/Level_2/cactus/4.png'),
                states.loading('images/Level_2/cactus/5.png'),
                states.loading('images/Level_2/cactus/6.png')
                ]

    enemies = [Cactus(states.Settings.WIDTH + 300 / random.uniform(0.8, 3), states.Settings.HEIGHT - 165,
                      textures[random.choice(list(range(6)))]),
               Cactus(states.Settings.WIDTH * 2 + 200 / random.uniform(0.8, 3), states.Settings.HEIGHT - 165,
                      textures[random.choice(list(range(6)))]),
               Cactus(states.Settings.WIDTH * 3 + 400 / random.uniform(0.8, 3), states.Settings.HEIGHT - 165,
                      textures[random.choice(list(range(6)))])]
    road_chunk = states.loading('images/Level_2/arcada.png')
    road_chunk_da = states.loading('images/Level_2/arcada_da.png')
    road_chunk_daa = states.loading('images/Level_2/arcada_1.png')
    road_chunk_daaa = states.loading('images/Level_2/arcada_daaa.png')
    pyray.draw_texture(road_chunk, 0, 0, colors.WHITE)
    dino = Dino(30, states.Settings.HEIGHT-250)

    # the loop
    while not pyray.window_should_close():
        if pyray.is_key_down(pyray.KeyboardKey.KEY_C):
            states.go_scene(5)
        pyray.begin_drawing()
        pyray.draw_texture(road_chunk_da, 10, 334, colors.WHITE)
        pyray.draw_texture(road_chunk_daa, 0, 462, colors.WHITE)
        # draw dino
        dino.update()
        dino.draw()
        # quit if there is no dinos left

        # generate enemies
        if len(enemies) < 3:
            enemies.append(Cactus(enemies[len(enemies) - 1].hitbox.x
                                  + states.Settings.WIDTH / random.uniform(0.8, 3), states.Settings.HEIGHT - 165,
                                  textures[random.choice(list(range(6)))]))

        # draw enemies
        rem_list = []
        for i, enemy in enumerate(enemies):
            enemy.update()
            enemy.draw()

            if not enemy.is_active:
                rem_list.append(i)
                continue

            if pyray.check_collision_recs(dino.box, enemy.hitbox):
                if score > 10:
                    score -= 250
                else:
                    score = 0

        for i in rem_list:
            enemies.pop(i)

        # read user input (jump test)
        if pyray.is_key_down(pyray.KeyboardKey.KEY_SPACE):
            if not dino.state == DinoState.JUMP:
                dino.jump()

        # score & game speed
        score += 0.5 * (game_speed / 4)
        if score > score_speedup:
            score_speedup += 100 * (game_speed / 2)
            game_speed += 1
            print(f"Game speed increased - {game_speed}")

        pyray.draw_texture(road_chunk_daaa, states.Settings.WIDTH - 200, 0, colors.WHITE)
        pyray.draw_text(f"Score: { str(math.floor(score))}", states.Settings.WIDTH - 200, 50, 20, colors.WHITE)

        if score > 2000:
            states.win(2)
            win()

        # flip & tick
        pyray.end_drawing()
    pyray.close_window()


if __name__ == "__main__":
    main()
