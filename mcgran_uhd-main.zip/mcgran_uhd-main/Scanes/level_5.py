import states
import pyray
from raylib import colors
import datetime


class Button:
    def __init__(self, x, y, texture):
        self.x = int(x)
        self.y = int(y)
        self.texture = texture

    def click(self):
        pyray.begin_drawing()
        if (self.x < pyray.get_mouse_x() < self.x + self.texture.width and
                self.y < pyray.get_mouse_y() < self.y + self.texture.height):
            if pyray.is_mouse_button_down(0):
                return 1
            pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)
        else:
            pyray.draw_texture(self.texture, self.x, self.y, colors.GRAY)
        pyray.end_drawing()


def lose():
    texture = states.loading('images/Level_1/win.png')
    texture_exit = states.loading('images/button/replay.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.draw_text("Try again :<", 440, 240, 24, colors.BLACK)
    pyray.end_drawing()
    exit_level = Button(states.Settings.WIDTH - states.Settings.WIDTH // 7, states.Settings.HEIGHT * 10 // 13,
                        texture_exit)

    while not pyray.window_should_close():
        if exit_level.click():
            pyray.close_window()
            main()
    pyray.close_window()


def win():
    texture = states.loading('images/Level_1/win.png')
    texture_exit = states.loading('images/button/exit.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.draw_text("And then Smirnov took MCgrana", 440, 240, 24, colors.BLACK)
    pyray.draw_text("to Yandex", 490, 270, 24, colors.BLACK)
    pyray.end_drawing()
    exit_level = Button(states.Settings.WIDTH - states.Settings.WIDTH // 7, states.Settings.HEIGHT * 10 // 13,
                        texture_exit)
    while not pyray.window_should_close():
        if exit_level.click():
            states.win(8)
            states.go_scene(9)
    pyray.close_window()


class Motorbike:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.z = 0
        self.speed = 4
        self.zspeed = 0
        self.texture = states.loading('images/Level_5/Smirnov.png')
        self.texture_run = states.loading('images/Level_5/Smirnov_run.png')
        self.animation = 0

    def draw(self):
        if self.animation < 5:
            pyray.draw_texture(self.texture, self.x, self.y - self.z, colors.WHITE)
        else:
            pyray.draw_texture(self.texture_run, self.x, self.y - self.z, colors.WHITE)
        self.animation = (self.animation + 1) % 10

    def move(self):
        self.z += int(self.zspeed)
        if self.z > 0:
            self.zspeed -= 0.25
        else:
            self.z = 0
            self.zspeed = 0
            if pyray.is_key_down(pyray.KeyboardKey.KEY_SPACE):
                self.zspeed = 8
        if pyray.is_key_down(pyray.KeyboardKey.KEY_D) and self.x < states.Settings.WIDTH - self.texture.width:
            self.x += self.speed
        elif pyray.is_key_down(pyray.KeyboardKey.KEY_A) and self.x > 0:
            self.x -= self.speed
        if pyray.is_key_down(pyray.KeyboardKey.KEY_W) and self.y > 520 - self.texture.height:
            self.y -= self.speed-1
        elif pyray.is_key_down(pyray.KeyboardKey.KEY_S) and self.y < 655 - self.texture.height:
            self.y += self.speed-1


class Hole:
    def __init__(self, y, z, width, ramp):
        self.x = states.Settings.WIDTH
        self.y = 515
        self.ramp_y = y * 36 + 510
        self.ramp_z = z * 100
        self.width = width
        self.height = 145
        self.speed = 20
        self.time = datetime.datetime.now()
        self.ramp = ramp

    def draw(self):
        if self.ramp:
            pyray.draw_triangle(pyray.Vector2(self.x - 21, self.ramp_y - self.ramp_z + 36),
                                pyray.Vector2(self.x - 56, self.ramp_y - self.ramp_z + 71),
                                pyray.Vector2(self.x - 21, self.ramp_y - self.ramp_z + 71), colors.DARKGRAY)

            pyray.draw_triangle(pyray.Vector2(self.x - 56, self.ramp_y - self.ramp_z + 71),
                                pyray.Vector2(self.x - 21, self.ramp_y - self.ramp_z + 36),
                                pyray.Vector2(self.x - 75, self.ramp_y - self.ramp_z), colors.BLACK)

            pyray.draw_triangle(pyray.Vector2(self.x - 21, self.ramp_y - self.ramp_z + 36),
                                pyray.Vector2(self.x - 40, self.ramp_y - self.ramp_z - 35),
                                pyray.Vector2(self.x - 75, self.ramp_y - self.ramp_z), colors.BLACK)

        pyray.draw_rectangle(self.x, self.y, self.width, self.height, colors.WHITE)

    def logik(self, motor):
        if self.x < motor.x and motor.x + motor.texture.width < self.x + self.width and motor.z == 0:
            lose()
        if self.ramp:
            if pyray.check_collision_lines(pyray.Vector2(self.x - 75, self.ramp_y),
                                           pyray.Vector2(self.x - 56, self.ramp_y + 71),
                                           pyray.Vector2(motor.x, motor.y + motor.texture.height),
                                           pyray.Vector2(motor.x + motor.texture.width, motor.y + motor.texture.height),
                                           pyray.Vector2(0, 0)) and abs(motor.z - self.ramp_z) < 25:
                motor.zspeed = int(5 + 2.5 * self.width//600)
            if (datetime.datetime.now() - self.time).seconds > 1:
                self.draw()
                self.x -= self.speed
                if self.x < -100 - self.width:
                    del self
            else:
                if (datetime.datetime.now() - self.time).microseconds % 500000 < 250000:
                    self.draw()
        else:
            self.draw()
            self.x -= self.speed
            if self.x < -100 - self.width:
                del self


class Wall:
    def __init__(self, x, y, light=1):
        self.x = x
        self.y = y
        self.light = light
        self.speed = 30
        self.time = datetime.datetime.now()
        self.texture = states.loading('images/Level_5/wall.png')

    def draw(self):
        pyray.draw_triangle(pyray.Vector2(self.x, self.y - 126), pyray.Vector2(self.x + 19, self.y - 55),
                            pyray.Vector2(self.x + 44, self.y - 55), colors.GRAY)
        pyray.draw_triangle(pyray.Vector2(self.x, self.y - 126), pyray.Vector2(self.x + 44, self.y - 55),
                            pyray.Vector2(self.x + 25, self.y - 126), colors.GRAY)

        pyray.draw_triangle(pyray.Vector2(self.x + 19, self.y + 71), pyray.Vector2(self.x + 44, self.y + 71),
                            pyray.Vector2(self.x + 19, self.y - 55), colors.DARKGRAY)
        pyray.draw_triangle(pyray.Vector2(self.x + 44, self.y + 71), pyray.Vector2(self.x + 44, self.y - 55),
                            pyray.Vector2(self.x + 19, self.y - 55), colors.DARKGRAY)

        pyray.draw_triangle(pyray.Vector2(self.x, self.y), pyray.Vector2(self.x + 19, self.y + 71),
                            pyray.Vector2(self.x, self.y - 126), colors.BLACK)
        pyray.draw_triangle(pyray.Vector2(self.x, self.y - 126), pyray.Vector2(self.x + 19, self.y + 71),
                            pyray.Vector2(self.x + 19, self.y - 55), colors.BLACK)

    def logik(self, motor):
        if pyray.check_collision_lines(pyray.Vector2(self.x, self.y), pyray.Vector2(self.x + 19, self.y + 71),
                                       pyray.Vector2(motor.x, motor.y + motor.texture.height),
                                       pyray.Vector2(motor.x + motor.texture.width, motor.y + motor.texture.height),
                                       pyray.Vector2(0, 0)):
            lose()
        if self.light:
            if (datetime.datetime.now() - self.time).seconds > 1:
                self.draw()
                self.x -= self.speed
                if self.x < -100:
                    del self
            else:
                if (datetime.datetime.now() - self.time).microseconds % 500000 < 250000:
                    self.draw()
        else:
            self.draw()
            self.x -= self.speed
            if self.x < -100:
                del self


class Down:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.speed = 22
        self.time = datetime.datetime.now()

    def draw(self):
        pyray.draw_triangle(pyray.Vector2(self.x, self.y - 41), pyray.Vector2(self.x + 19, self.y + 30),
                            pyray.Vector2(self.x + 44, self.y + 30), colors.GRAY)
        pyray.draw_triangle(pyray.Vector2(self.x, self.y - 41), pyray.Vector2(self.x + 44, self.y + 30),
                            pyray.Vector2(self.x + 25, self.y - 41), colors.GRAY)

        pyray.draw_triangle(pyray.Vector2(self.x + 19, self.y + 71), pyray.Vector2(self.x + 44, self.y + 71),
                            pyray.Vector2(self.x + 19, self.y + 30), colors.DARKGRAY)
        pyray.draw_triangle(pyray.Vector2(self.x + 44, self.y + 71), pyray.Vector2(self.x + 44, self.y + 30),
                            pyray.Vector2(self.x + 19, self.y + 30), colors.DARKGRAY)

        pyray.draw_triangle(pyray.Vector2(self.x, self.y), pyray.Vector2(self.x + 19, self.y + 71),
                            pyray.Vector2(self.x, self.y - 41), colors.BLACK)
        pyray.draw_triangle(pyray.Vector2(self.x, self.y - 41), pyray.Vector2(self.x + 19, self.y + 71),
                            pyray.Vector2(self.x + 19, self.y + 30), colors.BLACK)

    def logik(self, motor):
        if pyray.check_collision_lines(pyray.Vector2(self.x, self.y), pyray.Vector2(self.x + 19, self.y + 71),
                                       pyray.Vector2(motor.x, motor.y + motor.texture.height),
                                       pyray.Vector2(motor.x + motor.texture.width, motor.y + motor.texture.height),
                                       pyray.Vector2(0, 0)) and motor.z == 0:
            lose()
        if (datetime.datetime.now() - self.time).seconds > 1:
            self.draw()
            self.x -= self.speed
            if self.x < -100:
                del self
        else:
            if (datetime.datetime.now() - self.time).microseconds % 500000 < 250000:
                self.draw()


class Bug:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.speed = 2
        self.speed_y = 1

    def draw(self):
        pyray.draw_circle(self.x, self.y, 23, colors.DARKGRAY)
        pyray.draw_circle(self.x, self.y, 22, colors.BLACK)

    def logik(self, motor):
        if (pyray.check_collision_circle_rec(pyray.Vector2(self.x, self.y), 47,
                                             pyray.Rectangle(motor.x, motor.y + motor.texture.height,
                                                             motor.texture.width, 1)) and motor.z == 0):
            lose()
        self.draw()
        self.x -= self.speed
        if self.y > 630 or self.y < 538:
            self.speed_y *= -1
        self.y += self.speed_y
        if self.x < -100:
            del self


class Up:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.speed = 22
        self.time = datetime.datetime.now()

    def draw(self):
        pyray.draw_triangle(pyray.Vector2(self.x, self.y - 41), pyray.Vector2(self.x + 38, self.y + 101),
                            pyray.Vector2(self.x + 63, self.y + 101), colors.GRAY)
        pyray.draw_triangle(pyray.Vector2(self.x, self.y - 41), pyray.Vector2(self.x + 63, self.y + 101),
                            pyray.Vector2(self.x + 25, self.y - 41), colors.GRAY)

        pyray.draw_triangle(pyray.Vector2(self.x + 38, self.y + 142), pyray.Vector2(self.x + 63, self.y + 142),
                            pyray.Vector2(self.x + 38, self.y + 101), colors.DARKGRAY)
        pyray.draw_triangle(pyray.Vector2(self.x + 63, self.y + 142), pyray.Vector2(self.x + 63, self.y + 101),
                            pyray.Vector2(self.x + 38, self.y + 101), colors.DARKGRAY)

        pyray.draw_triangle(pyray.Vector2(self.x, self.y), pyray.Vector2(self.x + 38, self.y + 142),
                            pyray.Vector2(self.x, self.y - 41), colors.BLACK)
        pyray.draw_triangle(pyray.Vector2(self.x, self.y - 41), pyray.Vector2(self.x + 38, self.y + 142),
                            pyray.Vector2(self.x + 38, self.y + 101), colors.BLACK)

    def logik(self, motor):
        if self.x >= motor.x and motor.x + motor.texture.width >= self.x + 25 and motor.z != 0:
            lose()
        if (datetime.datetime.now() - self.time).seconds > 1:
            self.draw()
            self.x -= self.speed
            if self.x < -100:
                del self
        else:
            if (datetime.datetime.now() - self.time).microseconds % 500000 < 250000:
                self.draw()


class Fon:
    def __init__(self, x, y, texture):
        self.x = x
        self.y = y
        self.speed = 10
        self.texture = texture

    def draw(self):
        pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)

    def move(self):
        self.x -= self.speed
        if self.x < self.texture.width * -1:
            self.x = self.texture.width

    def logik(self):
        self.move()
        self.draw()


barrier = [
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [1, 'wall', 'right', 1],
    [1, 'wall', 'left', 1],
    [3, 'wall', 'left', 1],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [2, 'wall', 'right', 1],
    [2, 'wall', 'left', 1],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [6, 'wall', 'left', 1],
    [3, 'hole', 1, 0, 1],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [4, 'hole', 1, 0, 1],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [4, 'hole', 1, 0, 1],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [2, 'wall', 'left', 1],
    [6, 'hole', 1, 0, 1],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [6, 'hole', 1, 0, 1],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [2, 'up'],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [2, 'wall', 'left', 1],
    [2, 'wall', 'right', 1],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [2, 'up'],
    [6, 'hole', 1, 1, 1],
    [2, 'down', 'left'],
    [2, 'down', 'right'],
    [0, 'down', 'left'],
    [2, 'down', 'right'],
    [2, 'down', 'right'],
    [1, 'down', 'left'],
    [2, 'down', 'right'],
    [3, 'hole', 1, 1, 1],
    [0, 'down', 'left'],
    [1, 'down', 'right'],
    [2, 'wall', 'left', 1],
    [2, 'hole', 1, 0, 1],
    [2, 'hole', 1, 0, 1],
    [2, 'hole', 1, 0, 1],
    [0, 'down', 'left'],
    [1, 'down', 'right'],
    [0, 'down', 'left'],
    [1, 'down', 'right'],
    [5, 'hole', 2, 0, 1],
    [1, 'up'],
    [1, 'up'],
    [7, 'hole', 1, 1, 1],
    [4, 'bug'],
    [3, 'bug'],
    [4, 'bug'],
    [2, 'wall', 'left', 1],
    [2, 'hole', 1, 0, 1],
    [1, 'hole', 1, 1, 0],
    [1, 'hole', 1, 1, 0],
    [1, 'hole', 1, 1, 0],
    [1, 'hole', 1, 1, 0],
    [1, 'hole', 1, 1, 0],
    [3, 'down', 'left'],
    [1, 'wall', 'left', 0],
    [1, 'wall', 'right', 0],
    [1, 'wall', 'left', 0],
    [1, 'wall', 'right', 0],
    [1, 'wall', 'left', 0],
    [1, 'wall', 'right', 0],
    [1, 'wall', 'left', 0],
    [1, 'wall', 'right', 0],
    [1, 'wall', 'left', 0],
    [1, 'wall', 'right', 0],
    [1, 'wall', 'left', 0],
    [1, 'wall', 'right', 0],
    [1, 'wall', 'left', 0],
    [1, 'wall', 'right', 0],
    [1, 'wall', 'left', 0],
    [1, 'wall', 'right', 0],
    [1, 'wall', 'left', 0],
    [1, 'wall', 'right', 0],
    [1, 'wall', 'left', 0],
    [1, 'wall', 'right', 0],
    [0, 'down', 'left'],
    [1, 'down', 'right'],
    [0, 'down', 'left'],
    [1, 'down', 'right'],
    [0, 'down', 'left'],
    [1, 'down', 'right'],
    [10, 'down', 'left'],
    [1, 'up'],
]


def main():
    pyray.init_window(states.Settings.WIDTH, states.Settings.HEIGHT, 'GTZLP_Inc_MGRN_to_SHP')
    pyray.set_target_fps(120)  # FPS
    pyray.clear_background(colors.WHITE)
    smirnov = Motorbike(0, 401)
    start_time = datetime.datetime.now()
    i = 0
    wall = [Wall(1150, 515), Wall(1150, 515), Wall(1150, 515), Wall(1150, 515)]

    texture = states.loading('images/Level_5/town.png')
    fon1 = Fon(0, 0, texture)
    fon2 = Fon(texture.width, 0, texture)
    while not pyray.window_should_close():
        pyray.begin_drawing()
        fon1.logik()
        fon2.logik()
        smirnov.move()
        if i < len(barrier) - 1:
            if (datetime.datetime.now() - start_time).seconds >= barrier[i][0]:
                start_time += datetime.timedelta(seconds=barrier[i][0])
                i += 1
                if barrier[i][1] == 'wall':
                    if barrier[i][2] == 'left':
                        wall[i % 4] = Wall(1150, 515, barrier[i][3])
                    elif barrier[i][2] == 'right':
                        wall[i % 4] = Wall(1169, 586, barrier[i][3])
                elif barrier[i][1] == 'down':
                    if barrier[i][2] == 'left':
                        wall[i % 4] = Down(1150, 515)
                    elif barrier[i][2] == 'right':
                        wall[i % 4] = Down(1169, 586)
                elif barrier[i][1] == 'up':
                    wall[i % 4] = Up(1150, 405)
                elif barrier[i][1] == 'hole':
                    wall[i % 4] = Hole(barrier[i][2], barrier[i][3], (barrier[i][0] - barrier[i][4])*600, barrier[i][4])
                elif barrier[i][1] == 'bug':
                    wall[i % 4] = Bug(1150, 555)
        else:
            win()
        wall[0].logik(smirnov)
        wall[1].logik(smirnov)
        wall[2].logik(smirnov)
        wall[3].logik(smirnov)
        smirnov.draw()
        pyray.end_drawing()
    pyray.close_window()


if __name__ == '__main__':
    main()
