import states
import pyray
from raylib import colors


class Settings:
    WIDTH = 1300
    HEIGHT = 800


class Button:
    def __init__(self, x, y, texture):
        self.x = int(x)
        self.y = int(y)
        self.texture = texture

    def click(self):
        pyray.begin_drawing()
        if (self.x < pyray.get_mouse_x() < self.x + self.texture.width and
                self.y < pyray.get_mouse_y() < self.y + self.texture.height):
            if pyray.is_mouse_button_down(0):
                return 1
            pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)
        else:
            pyray.draw_texture(self.texture, self.x, self.y, colors.GRAY)
        pyray.end_drawing()


def draw_blocks(texture_mc, texture_monster, texture_bear, texture_perry):
    # ПОДСВЕТКА ТЕКУЩЕГО ПЕРСОНАЖА
    if states.APPEARANCE == 0:
        pyray.draw_texture(texture_mc, Settings.WIDTH // 3, Settings.HEIGHT // 4, colors.GRAY)
        pyray.draw_texture(texture_monster, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 4,
                           colors.GRAY)
        pyray.draw_texture(texture_bear, Settings.WIDTH // 3, Settings.HEIGHT // 2, colors.GRAY)
        pyray.draw_texture(texture_perry, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 2, colors.GRAY)
    elif states.APPEARANCE == 1:
        pyray.draw_texture(texture_mc, Settings.WIDTH // 3, Settings.HEIGHT // 4, colors.WHITE)
        pyray.draw_texture(texture_monster, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 4,
                           colors.GRAY)
        pyray.draw_texture(texture_bear, Settings.WIDTH // 3, Settings.HEIGHT // 2, colors.GRAY)
        pyray.draw_texture(texture_perry, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 2, colors.GRAY)
    elif states.APPEARANCE == 2:
        pyray.draw_texture(texture_monster, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 4,
                           colors.WHITE)
        pyray.draw_texture(texture_mc, Settings.WIDTH // 3, Settings.HEIGHT // 4, colors.GRAY)
        pyray.draw_texture(texture_bear, Settings.WIDTH // 3, Settings.HEIGHT // 2, colors.GRAY)
        pyray.draw_texture(texture_perry, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 2, colors.GRAY)
    elif states.APPEARANCE == 3:
        pyray.draw_texture(texture_bear, Settings.WIDTH // 3, Settings.HEIGHT // 2, colors.WHITE)
        pyray.draw_texture(texture_mc, Settings.WIDTH // 3, Settings.HEIGHT // 4, colors.GRAY)
        pyray.draw_texture(texture_monster, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 4,
                           colors.GRAY)
        pyray.draw_texture(texture_perry, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 2, colors.GRAY)
    elif states.APPEARANCE == 4:
        pyray.draw_texture(texture_perry, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 2, colors.WHITE)
        pyray.draw_texture(texture_mc, Settings.WIDTH // 3, Settings.HEIGHT // 4, colors.GRAY)
        pyray.draw_texture(texture_monster, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 4,
                           colors.GRAY)
        pyray.draw_texture(texture_bear, Settings.WIDTH // 3, Settings.HEIGHT // 2, colors.GRAY)
    else:
        print('CHARACTER.PY - Выбирается несуществующий перс')


def main():
    pyray.init_window(Settings.WIDTH, Settings.HEIGHT, "MCGRAN")
    pyray.set_target_fps(120)

    texture = states.loading('images/characters/wardrobe.png')
    texture_exit = states.loading('images/button/exit.png')
    texture_bear = states.loading('images/characters/bear.png')
    texture_monster = states.loading('images/characters/monstr.png')
    texture_perry = states.loading('images/characters/perry.png')
    texture_mc = states.loading('images/characters/MC.png')

    texture_character = states.appearance_who()

    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.end_drawing()

    exit_level = Button(Settings.WIDTH * 10 // 25, Settings.HEIGHT // 2 + Settings.HEIGHT // 4, texture_exit)

    while not pyray.window_should_close():

        pyray.draw_texture(texture_character, Settings.WIDTH // 11, Settings.HEIGHT // 2 + Settings.HEIGHT // 12,
                           colors.WHITE)
        draw_blocks(texture_mc, texture_monster, texture_bear, texture_perry)

        # ПОДСВЕТКА ВЫБИРАЕМОГО ПЕРСОНАЖА
        if (Settings.WIDTH // 3 < pyray.get_mouse_x() < Settings.WIDTH // 3 + texture_mc.width and
                Settings.HEIGHT // 4 < pyray.get_mouse_y() < Settings.HEIGHT // 4 + texture_mc.height):
            if pyray.is_mouse_button_pressed(0):
                if states.APPEARANCE != 1:
                    states.APPEARANCE = 1
                    states.NAME = 'MCgran'
                    pyray.draw_texture(texture, 0, 0, colors.WHITE)
                    texture_character = states.appearance_who()
            else:
                pyray.draw_texture(texture_mc, Settings.WIDTH // 3, Settings.HEIGHT // 4, colors.LIGHTGRAY)
        if (Settings.WIDTH // 3 + Settings.WIDTH // 7 < pyray.get_mouse_x() <
                Settings.WIDTH // 3 + Settings.WIDTH // 7 + texture_monster.width and
                Settings.HEIGHT // 4 < pyray.get_mouse_y() < Settings.HEIGHT // 4 + texture_monster.height):
            if pyray.is_mouse_button_pressed(0):
                if states.APPEARANCE != 2:
                    states.APPEARANCE = 2
                    states.NAME = 'monster'
                    pyray.draw_texture(texture, 0, 0, colors.WHITE)
                    texture_character = states.appearance_who()
            else:
                pyray.draw_texture(texture_monster, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 4,
                                   colors.LIGHTGRAY)
        if (Settings.WIDTH // 3 < pyray.get_mouse_x() < Settings.WIDTH // 3 + texture_bear.width and
                Settings.HEIGHT // 2 < pyray.get_mouse_y() < Settings.HEIGHT // 2 + texture_bear.height):
            if pyray.is_mouse_button_pressed(0):
                if states.APPEARANCE != 3:
                    states.APPEARANCE = 3
                    states.NAME = 'bear'
                    pyray.draw_texture(texture, 0, 0, colors.WHITE)
                    texture_character = states.appearance_who()
            else:
                pyray.draw_texture(texture_bear, Settings.WIDTH // 3, Settings.HEIGHT // 2, colors.LIGHTGRAY)
        if (Settings.WIDTH // 3 + Settings.WIDTH // 7 < pyray.get_mouse_x() <
                Settings.WIDTH // 3 + Settings.WIDTH // 7 + texture_perry.width and
                Settings.HEIGHT // 2 < pyray.get_mouse_y() < Settings.HEIGHT // 2 + texture_perry.height):
            if pyray.is_mouse_button_pressed(0):
                if states.APPEARANCE != 4:
                    states.APPEARANCE = 4
                    states.NAME = 'perry'
                    pyray.draw_texture(texture, 0, 0, colors.WHITE)
                    texture_character = states.appearance_who()
            else:
                pyray.draw_texture(texture_perry, Settings.WIDTH // 3 + Settings.WIDTH // 7, Settings.HEIGHT // 2,
                                   colors.LIGHTGRAY)

        # ВЫХОД
        if exit_level.click():
            states.go_scene(0)

        pyray.end_drawing()
    pyray.close_window()


if __name__ == '__main__':
    main()
