import datetime
import random

import states
import pyray
from raylib import colors


Push = 0


class Button:
    def __init__(self, x, y, texture):
        self.x = int(x)
        self.y = int(y)
        self.texture = texture

    def click(self):
        pyray.begin_drawing()
        if (self.x < pyray.get_mouse_x() < self.x + self.texture.width and
                self.y < pyray.get_mouse_y() < self.y + self.texture.height):
            if pyray.is_mouse_button_down(0):
                return 1
            pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)
        else:
            pyray.draw_texture(self.texture, self.x, self.y, colors.GRAY)
        pyray.end_drawing()


class ButtonText:
    def __init__(self, x, y, width, height, text):
        self.x = int(x)
        self.y = int(y)
        self.width = int(width)
        self.height = int(height)
        self.text = text

    def click(self):
        pyray.begin_drawing()
        if (self.x < pyray.get_mouse_x() < self.x + self.width and
                self.y < pyray.get_mouse_y() < self.y + self.height):
            if pyray.is_mouse_button_down(0):
                return 1
            pyray.draw_rectangle(self.x, self.y, self.width, self.height, colors.WHITE)
            pyray.draw_text(self.text, self.x + 60, self.y + 70, 30, colors.BLACK)
        else:
            pyray.draw_rectangle(self.x, self.y, self.width, self.height, colors.GRAY)
            pyray.draw_text(self.text, self.x + 60, self.y + 70, 30, colors.BLACK)
        pyray.end_drawing()


def win():
    texture = states.loading('images/Level_1/win.png')
    texture_exit = states.loading('images/button/exit.png')
    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.draw_text("McGraw arrived at the station.", 440, 240, 24, colors.BLACK)
    pyray.draw_text("It's time to move on", 440, 280, 24, colors.BLACK)
    pyray.end_drawing()
    exit_level = Button(states.Settings.WIDTH - states.Settings.WIDTH // 7, states.Settings.HEIGHT * 10 // 13,
                        texture_exit)
    while not pyray.window_should_close():
        if exit_level.click():
            states.go_scene(7)
    pyray.close_window()


def lose():
    global Push
    texture = states.loading('images/Level_1/win.png')
    texture_exit = states.loading('images/button/replay.png')

    pyray.begin_drawing()
    pyray.draw_texture(texture, 0, 0, colors.WHITE)
    pyray.draw_text("Try again :<", 440, 240, 24, colors.BLACK)
    pyray.end_drawing()
    exit_level = Button(states.Settings.WIDTH - states.Settings.WIDTH // 7, states.Settings.HEIGHT * 10 // 13,
                        texture_exit)

    while not pyray.window_should_close():
        if exit_level.click():
            Push = 0
            pyray.close_window()
            main()
    pyray.close_window()


class Picture:
    def __init__(self, tipe, x, y):
        self.type = tipe
        self.x = x
        self.y = y
        self.width = 100
        self.height = 160
        self.log = 0
        self.texture = states.loading(f'images/Level_3/card{self.type+1}.png')
        self.textureback = states.loading(f'images/Level_3/card.png')
        self.draw()

    def draw(self):
        if self.log == 1:
            pyray.draw_texture(self.texture, self.x, self.y, colors.WHITE)
        elif self.log == 0:
            pyray.draw_texture(self.textureback, self.x, self.y, colors.WHITE)

    def logik(self, pair):
        global Push
        if len(pair) == 3:
            if (pair[0].type != pair[1].type or pair[0] == pair[1]) and pair[0].log == 1 and pair[1].log == 1:
                pair[0].log = 0
                pair[1].log = 0
                pair[0].draw()
                pair[1].draw()
                Push += 1
            else:
                pair[0].log = 2
                pair[1].log = 2

            pair = [pair[2]]
        if (self.x < pyray.get_mouse_x() < self.x + self.width and
                self.y < pyray.get_mouse_y() < self.y + self.height and
                pyray.is_mouse_button_pressed(0) and self.log == 0):
            self.log = 1
            pair.append(self)
            self.draw()
        return pair


def main():
    pyray.init_window(states.Settings.WIDTH, states.Settings.HEIGHT, 'GTZLP_Inc_MGRN_to_SHP')
    pyray.set_target_fps(120)
    pictures = []
    time = datetime.datetime.now()
    pair = []
    texture_fon = states.loading('images/Level_3/bus.png')
    easy = ButtonText(states.Settings.WIDTH // 2.3 - states.Settings.WIDTH // 8, states.Settings.HEIGHT * 10 // 22,
                      160, 160, 'Hard')
    normal = ButtonText(states.Settings.WIDTH // 2.2, states.Settings.HEIGHT*10 // 22,
                        160, 160, 'Hard')
    hard = ButtonText(states.Settings.WIDTH * 10 // 21 + states.Settings.WIDTH // 8, states.Settings.HEIGHT * 10 // 22,
                      160, 160, 'Hard')
    pyray.begin_drawing()
    pyray.draw_texture(texture_fon, 0, 0, colors.WHITE)
    pyray.end_drawing()
    while not pyray.window_should_close():
        if easy.click():
            pyray.draw_rectangle(0, 0, states.Settings.WIDTH, states.Settings.HEIGHT, colors.BLACK)
            break

        if normal.click():
            pyray.draw_rectangle(0, 0, states.Settings.WIDTH, states.Settings.HEIGHT, colors.BLACK)
            break

        if hard.click():
            pyray.draw_rectangle(0, 0, states.Settings.WIDTH, states.Settings.HEIGHT, colors.BLACK)
            break

        pyray.end_drawing()
    rand = random.sample(list(range(0, 22))+list(range(0, 22)), 44)
    for i in range(44):
        pictures.append(Picture(rand[i], 50 + i % 11 * ((1200 - 1100)//10 + 100),
                                50 + (i // 11) * 170))
    pyray.begin_drawing()
    for i in pictures:
        i.log = 1
        i.draw()
        i.log = 0
    pyray.end_drawing()
    while not pyray.window_should_close():
        pyray.begin_drawing()
        if (datetime.datetime.now() - time).seconds > 10:
            winner = [0, 0]
            for i in pictures:
                pair = i.logik(pair)
                if i.log == 2:
                    winner[0] += 1
                if i.log == 1:
                    winner[1] += 1
            if winner[0] == 42 and winner[1] == 2:
                states.win(3)
                win()
            pyray.draw_rectangle(100, 0, 100, 30, colors.BLACK)
            pyray.draw_text(f'OCTALOC Push: {30 - Push}', 0, 0, 20, colors.WHITE)
            if Push >= 30:
                lose()
        elif (datetime.datetime.now() - time).seconds == 10:
            for i in pictures:
                i.draw()
            pyray.draw_rectangle(0, 0, 200, 30, colors.BLACK)
        else:
            pyray.draw_rectangle(100, 0, 100, 30, colors.BLACK)
            pyray.draw_text(f'OCTALOC: {10 - (datetime.datetime.now() - time).seconds} s', 0, 0, 20, colors.WHITE)

        pyray.end_drawing()
    pyray.close_window()


if __name__ == '__main__':
    main()
