import pyray
import start_menu
from Scanes import character
from Scanes import map
from Scanes import level_1
from Scanes import level_2
from Scanes import level_3
from Scanes import level_4
from Scanes import level_5
from Scanes import Win_MSHP
from Scanes import Win_YNDX


# Файл ГЛОБАЛЬНЫХ переменных
class Settings:
    WIDTH = 1300
    HEIGHT = 800


ROOM = 3

HP = 3
TIME = 0
GLASSES = 0

NAME = 'MCgran'
APPEARANCE = 1

SOUND = True
TITLE = ''

DIE = 3
KEY = False
#        lining  kitch  door   bed
LIGHT = [False, False, False, False]


def get_win():
    f = open('States.txt', 'r')
    winner = int(f.read())
    f.close()
    return winner


def win(lvl):
    f = open('States.txt', 'w')
    f.write(str(lvl))
    f.close()


def loading(image_name):
    image = pyray.load_image(image_name)
    texture = pyray.load_texture_from_image(image)
    pyray.unload_image(image)
    del image
    return texture


def go_scene(scene):
    pyray.end_drawing()
    pyray.close_window()
    if scene == 0:
        # Открываем меню начала игры
        start_menu.main()
    elif scene == 1:
        # Открываем уровень_1 - Шерлок
        level_1.main()
    elif scene == 2:
        # Открываем уровень_2 - Дино
        level_2.main()
    elif scene == 3:
        # Открываем уровень_3 - Автобульбуль
        level_3.main()
    elif scene == 4:
        # Открываем уровень_4 - Лабиринт
        level_4.main()
    elif scene == 5:
        # Открываем уровень_5 - Смирнов
        level_5.main()
    elif scene == 6:
        # Открываем настройку личности
        character.main()
    elif scene == 7:
        # Открываем карту
        map.main()
    elif scene == 8:
        # Открываем MSHP
        Win_MSHP.main()
    elif scene == 9:
        # Открываем YNDX
        Win_YNDX.main()
    else:
        print('Ошибка, где-то лишний уровень')
        pass



def appearance_who():
    appearances = [loading('images/characters/MCgran.png'),
                   loading('images/characters/monstr_character.png'),
                   loading('images/characters/grisha.png'),
                   loading('images/characters/perry_character.png')]
    return appearances[APPEARANCE - 1]


def room_texture(room, light):
    textures = [loading('images/Level_1/dark_room.png'),
                loading('images/Level_1/living_room.png'),
                loading('images/Level_1/kitchen1.png'),
                loading('images/Level_1/light_door_room.png'),
                loading('images/Level_1/bedroom.png')]
    if not light:
        room = 0
    return textures[room]


SLOVAR_LIVING_ROOM = {
    "light": ["So this is what light looks like",
              "Turn it off? Turn it off?",
              "How long have I had this chandelier?",
              "If the light is on, it's light. If the light is not on, it is dark.",
              "Let there be light! Although, maybe it should be turned off?"],
    "clock": ["It seems to be lunch time!", "I'm late for something",
              "Is it my imagination or is my watch not running?",
              "Tick-tock, tick-tock, tick-tock",
              "What time is it now?"],
    "axolotl": ["I love axolotls",
                "Bul-bul-bul-bul-bul",
                "Squish-squish-squish",
                "Hmmmm, shouldn't he live in an aquarium?",
                "Nyashka"],
    "sofa": ["The main thing is not to fall asleep..",
             "Can I lie down to sleep?",
             "The sofa is a wonderful creature",
             "A soft sofa ...",
             "Can I be Oblomov?"],
    "phone": ["Ding-ding, ding-ding! (-Who's there?) (-Sorry, wrong number...)",
              "can I call someone? Nah, laziness",
              "Why do I need a landline phone?",
              "So, where's my phone? Maybe he left it in the kitchen?",
              "Hmm, can it be hacked?"],
    "safe": ["I hope there's money in there",
             "How much does it weigh? I can't even lift it!",
             "In movies, safes are easily hacked, but in reality it's too difficult..",
             "Safe",
             "Closed"],
    "notes": ["Notes, notes and notes again",
              "How much flour is here",
              "So, notes, interesting",
              "I completely forgot! Tomorrow is the deadline for English!",
              "Oh, there are even sketches for the packman"],
    "shelf": ["Shelf",
              "There's a shelf here, but the closet is more convenient, there's more to stuff in there",
              "So, I've been planning to hang another shelf for a long time",
              "Hmm, how many things can it hold?",
              "Where are my glasses?"],
    "book": ["What an interesting book, I'll put it aside for later",
             "Oh, tomorrow is literature.. Well, okay, let's take a walk",
             "I love to read, I wish I had time",
             "Hmmm, where is my Dracula lying?",
             "So many books that they don't fit in the closet anymore"],
    "vase": ["The main thing is not to break it",
             "Hmm, a vase without flowers?",
             "Beautiful",
             "I will need to buy flowers and put them in a vase",
             "Mom's vase, but it's in my room"],
    "cupboard": ["Books, books and books again",
                 "I want more books! I'll have to go to the store.",
                 "Maybe buy a new manga? There's just recently been a new edition",
                 "A short story or a manga? It's hard to choose..",
                 "So, where is the classic here? Hmmm.. Like at the top"],
    "paint": ["My favourite landscape",
              "It is a very beautiful paint",
              "It was painted by a very famous painter",
              "Love this picture",
              "How long I have this thing? Maybe 3 or 5 years?"]
}
SLOVAR_DVERI = {
    "light": ["So this is what the light looks like",
              "Turn it off? Turn it off?",
              "How long have I had this chandelier?",
              "If the light is on, it's light. If the light is not on, it's dark.",
              "Let there be light! Although, maybe it should be turned off?"],
    "door_MSHP": ["It is a pity that the door is closed!",
                  "I wonder what is behind the door?",
                  "It would be nice to be in the MSHP now!",
                  "How are our teachers?",
                  "Need to be at the MSHP on time!"],
    "door_YNDX": ["What delicious cookies are on Yandex!",
                  "I would like to get to Yandex as soon as possible!",
                  "I wonder what awaits us in the next lesson?",
                  "Yandex is so cool!",
                  "The project will be protected in Yandex soon!"],
    "door_kill": ["I wonder what's behind the door?",
                  "Someone has already entered there!",
                  "What kind of tension is there?",
                  "Maybe someone is there?",
                  "I want to open this door!"]
}
SLOVAR_KITCHEN = {
    "light": ["So this is what light looks like",
              "Turn it off? Turn it off?",
              "How long have I had this chandelier?",
              "If the light is on, it's light. If the light is not on, it is dark.",
              "Let there be light! Although, maybe it should be turned off?"],
    "table": ["Where is the food?",
              "It seemed to me that there was a plate on the table",
              "What a big table",
              "I wonder how old is he?",
              "I just like to sit leaning on the table"],
    "chair": ["What a comfortable chair!",
              "It seemed to me that his place was in my room",
              "It's worth changing the upholstery",
              "I don't want to buy a new chair",
              "I remember falling off this chair"],
    "JBL": ["I really want to listen to my favorite song!",
            "I remember buying this column",
            "It used to look bigger",
            "Maybe annoy the neighbors?",
            "It's been a long time since I've just sat and listened to music"],
    "oven": ["Let's see what we have here?",
             "I'm so hungry!",
             "I wish I could cook!",
             "How does it turn on?",
             "If you try, something will work out!"],
    "microwave": ["Cool, microwave!",
                  "Dachshund, there're pancakes somewhere here, I can warm them up",
                  "Cheese sandwiches in the microwave are very tasty",
                  "Boo, we waves-waves-waves",
                  "The most useful thing in the kitchen!"],
    "crocodile": ["My crocodile",
                  "Ha-ha-ha, I have a croco in my ventilation",
                  "He is so cute",
                  "Wow, I'm surprised",
                  "Hope, he won't eat my axolotl"],
    "cupboard": ["Some dishes are here",
                 "Yes, I have lots of cupboards",
                 "Why I have so many cupboards?",
                 "The Dishes, the cups, the spoons...",
                 "My kitchen is very beautiful"],
    "picture": ["Hackaton from MSHP",
                "I want to take part in creating telegram-bot",
                "I have a project about telegram-bot",
                "It will bw interesting",
                "Oh, it was in APRIL! And now it's MAY!"],
}
SLOVAR_BEDROOM = {
    "window": ["How high do I live?",
               "Oh, my neighbor!",
               "I think he's fighting with someone",
               "Where are my binoculars?",
               "I think there's nothing interesting there"],
    "cactus": ["How prickly he is!",
               "Should I water it?",
               "Should bloom soon",
               "I'll buy another one sometime",
               "I think my apartment will look like a flower garden soon!"],
    "table": ["I think it's worth tidying up the table",
              "Maybe I can find something",
              "Have I always sat at such a dirty table?",
              "Where's my pen?",
              "It seemed to me that all pens should be in the table"],
    "chair": ["", "", "", "", ""],
    "comp": ["What should I do?",
             "Maybe I should start doing a project?",
             "No, it's a bad idea",
             "Although there are 10 minutes left before the exit...",
             "No, it's not that important"],
    "calendar": ["23:59 - is a deadline",
                 "Today 26 of May",
                 "Monday, Tuesday, Wednesday, Thursday, Friday, Sunday~",
                 "Today 26 of May",
                 "Today 26 of May"],
    "bed": ["I really want to sleep...",
            "I haven't sleep all night because I was doing my project",
            "Sleep or not sleep? It's not a question",
            "I have so interesting dream tonight...",
            "Hrrr-beee-bii-be-bi-bi-biiii"],
    "guitar": ["Let's play rock-n-roll!",
               "I haven't play this guitar for 3 month",
               "Maybe it is a time to start playing?",
               "Rock or classic? Difficult question",
               "Pum-pim-piu-pam-dum-dam"],
    "book": ["My books",
             "Why these books are here? They should be in living room",
             "Hmmm, maybe i can read now? Nope, it's boring",
             "These student books are here",
             "I have Stiven King's books for the next time"],
    "ship": ["bul, bul, bul, bul, bul",
             "My favourite ship",
             "It was a present from my parnts",
             "I love Pirates from the Caribbean",
             "It's name is 'Confection'"],
    "mop": ["Why is this all if there is a vacuum cleaner?",
            "Print 'C' in the next level, a clue from M.D.",
            "Print 'C' in the next level, a clue from M.D.",
            "Print 'C' in the next level, a clue from M.D.",
            "It's so comfortable to have it in the room"],
    "TV": ["Oh, it's time to watch this new show!",
           "Like Tv",
           "Welcome to the TV world!",
           "Press any button to continue watching",
           "Now playing: [the name of a show]"],
    "cupboard": ["Another cupboard in my room",
                 "I have some DVD's here",
                 "May be I should open it? Ha-ha, nope",
                 "What is here? Games for my Xbox",
                 "Here are also some comics"],
}
SLOVAR_GAME = {
    "door": "Maybe I have a hint in my laptop? ",
    "comp": ["What is your password? You don't know it! GO AWAY!!!", "It's a correct password! ^V^"],
    "note": "COMP PASSWORD 1506432",
    "comp_email": "Hello! I hid your door key, so good luck finding it! Makushenko D.Yu."

}
GAME = [0, # Нажал на двери и получил подсказку, что нужен комп                            (0)  (+)
        0, # Записка на полу: COMP PASSWORD 1506432                                        (1)  (+)
        0, # Comp open                                                                     (2)  (+)
        0, # comp email (a29yemluYQ== [корзина])                                           (3)  (+)
        0, # Проверь корзину на компе [Цезарь 13]                                          (4)  (+)
        0, # Корзина в комнате: Сегодня я добрый. Нажми C на следующем уровне              (5)  (+)
        0, # Салат: Проверь время (ЦЕЗАРЬ Цезарь 13)                                       (6)  (+)
        0, # Часы: Хаха, оно не тут, лучше проверь заметки, там весело [ASCI]              (7)  (+)
        0, # Записки на стене: Сделал дз по сетям? Проверь цветок (Cибирь)                 (8)  (+)
        0, # Цветок: Морской бой. Ship. (HEX)                                              (9)  (+)
        0] # Корабль: Итоговый пароль: proms101                                            (10) (+)
